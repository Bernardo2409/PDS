package Jogodogalo;

public class JGaloJogo implements JGaloInterface{
    private char player;
    private char[][] tabuleiro;
    private final int SIZE = 3;

    JGaloJogo(){
        this.player = 'X';
        this.tabuleiro = new char[SIZE][SIZE];
        fillTabuleiro();
    }

    public void fillTabuleiro(){
        for (int lin = 0; lin < SIZE; lin++){
            for (int col = 0; col < SIZE; col++){
                tabuleiro[lin][col] = '-';
            }
        }
    }

    @Override
    public char getActualPlayer(){
        return this.player;
    }

    @Override
    public boolean setJogada(int lin, int col){
        int linCoordinate = changeCoordinates(lin);
        int colCoordinate = changeCoordinates(col);

        if(tabuleiro[linCoordinate][colCoordinate] == '-'){
            tabuleiro[linCoordinate][colCoordinate] = this.player;
            changePlayer();
            return true;
        }
        changePlayer();
        return false;

    }

    @Override
    public boolean isFinished() {
        
        if (checkResult() != ' ') {
                return true;
        }
        //se ainda há casas vazias (jogo continua)
        for (int lin = 0; lin < 3; lin++) {
            for (int col = 0; col < 3; col++) {
                if (tabuleiro[lin][col] == '-') {
                    return false;
                }
            }
        }
        //empate
        return true;
    }

    public char checkResult(){

        for (int lin = 0; lin < 3; lin++) {
            if (checkLines(lin)) {
                return tabuleiro[lin][0];
            }
        }

        for (int col = 0; col < 3; col++) {
            if (checkColumns(col)) {
                return tabuleiro[0][col];
            }
        }

        if (checkMainDiagonal()) {
            return tabuleiro[0][0];
        }

        if (checkSecondaryDiagonal()) {
            return tabuleiro[0][2];
        }
        
        return ' ';
    }

    public int changeCoordinates(int coordinate){
        switch (coordinate) {
            case 1:
                return 0;
            case 2:
                return 1;
            case 3:
                return 2;
            default:
                return -1;
        }
    }


    private void changePlayer(){
        if(this.player == 'X'){
            this.player = 'O';
        }else{
            this.player = 'X';
        }
    }

    private boolean checkLines(int lin){
        return tabuleiro[lin][0] != '-' &&
                tabuleiro[lin][0] == tabuleiro[lin][1] &&
                tabuleiro[lin][1] == tabuleiro[lin][2];
    }

    private boolean checkColumns(int col){
        return tabuleiro[0][col] != '-' &&
                tabuleiro[0][col] == tabuleiro[1][col] &&
                tabuleiro[1][col] == tabuleiro[2][col]; 
    }

    private boolean checkMainDiagonal(){
        return tabuleiro[0][0] != '-' &&
            tabuleiro[0][0] == tabuleiro[1][1] &&
            tabuleiro[1][1] == tabuleiro[2][2];
    }

    private boolean checkSecondaryDiagonal(){
        return tabuleiro[0][2] != '-' &&
            tabuleiro[0][2] == tabuleiro[1][1] &&
            tabuleiro[1][1] == tabuleiro[2][0];
    }
}
