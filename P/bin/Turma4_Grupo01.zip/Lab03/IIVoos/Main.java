package IIVoos;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner sc;
        String line;
        FlightManager flightmanager = new FlightManager();
        if (args.length > 0) {
            try {
                sc = new Scanner(new File(args[0]));
            } catch (FileNotFoundException e) {
                System.out.println("Ficheiro não encontrado: " + args[0]);
                return;
            }
        } else {
            sc = new Scanner(System.in);
        }

        System.out.println("Gestão de Voos - Exercício 2");

        while (true) {
            if(args.length == 0){System.out.print("\nEscolha uma opção: (H para ajuda)\n> ");}
            line = sc.nextLine();
            if (line == null) break;
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\\s+");
            String cmd = parts[0].toUpperCase();

            switch (cmd) {
                case "H":
                    printHelp();
                    break;

                case "F": // Criar voo
                    if (parts.length < 3 || parts.length > 4) {
                        System.out.println("Uso: F <código> <execNxM ou -> <turNxM>");
                        break;
                    }
                    flightmanager.createFlight(FlightManager.removeCommandDigit(parts));
                    break;

                case "M": // Mostrar mapa
                    if (parts.length != 2) {
                        System.out.println("Uso: M <código_voo>");
                        break;
                    }
                    flightmanager.searchFlightPlaneMap(parts[1]);
                    break;

                case "I": // Importar ficheiro
                    flightmanager.readFlightFile(parts[1]);
                    break;

                case "R": // Criar reserva
                    if (parts.length != 4){
                        System.out.println("Uso: R <codigo_voo> <T|E> <n>");
                        break;
                    }
                    flightmanager.prepareInputToReserve(parts);
                    break;

                case "C": // Cancelar reserva
                    if (parts.length != 2) {
                        System.out.println("Uso: C <codigo_voo>:<num_reserva>");
                        break;
                    }
                    flightmanager.prepareInputTocancelReservation(parts);
                    break;
                case "Q": // Sair
                    System.out.println("A terminar...");
                    return;

                default:
                    System.out.println("Comando desconhecido. Escreva H para ajuda.");
            }
        }
        sc.close();
    }

    private static void printHelp() {
        System.out.println("Comandos disponíveis:");
        System.out.println("H                         : ajuda");
        System.out.println("I <ficheiro>              : importar voo e reservas de ficheiro");
        System.out.println("M <codigo_voo>            : mostrar mapa de reservas");
        System.out.println("F <codigo> <exec|-> <tur> : criar voo (ex.: F TP1920 3x2 15x3 ou F TP1930 - 20x4)");
        System.out.println("R <codigo_voo> <T|E> <n>  : nova reserva");
        System.out.println("C <voo:reserva>           : cancelar reserva");
        System.out.println("Q                         : sair");
    }

}
