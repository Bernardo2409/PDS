package IIVoos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Arrays;

public class FlightManager {
    private final Map<String, Flight> flights = new HashMap<>();

    public  void createFlight(String[] parts) {
        String code = parts[0];
        int[] exec = null;
        int[] tour;
        if (parts.length == 2) {
            tour = parseNxM(parts[1]);
        } else {
            exec = parseNxM(parts[1]);
            tour = parseNxM(parts[2]);
        }

        Plane associatedPlane = choosePlaneToFlight(exec, tour);
        Flight newFlight = new Flight(code, associatedPlane);
        addNewFlight(code, newFlight);
    }

    public void reserveFlight(String flightCode,String[] parts) {
        try{
            String classType = parts[0].trim().toUpperCase();
            boolean isExecutive = Flight.isExecutiveInput(classType);

            
            if(!hasFlight(flightCode)){
                System.out.println("Voo nao encontrado");
                return;
            }
            Flight flight = flights.get(flightCode);
            int quantity = Integer.parseInt(parts[1]);
            List<Seat> reserved = flight.reserveSeats(quantity, isExecutive);
            if (reserved == null) {
                System.out.printf("Não foi possível obter lugares para a reserva: %s %d%n", classType, quantity);
                return;
            }
            int reservationId = flight.getLastReservationId();
            System.out.print(flight.getFlightCode() + ":" + reservationId + " = ");
            for (int i = 0; i < reserved.size(); i++) {
                System.out.print(reserved.get(i));
                if (i < reserved.size() - 1) System.out.print(" | ");
            }
            System.out.println();
        }catch (NumberFormatException e){
            System.out.println("Número inválido");
        }
        
    }


    public void prepareInputTocancelReservation(String[] parts){
        String[] partsWhithoutCommand = removeCommandDigit(parts);
        String[] cancelParts = partsWhithoutCommand[0].split(":");
        if (cancelParts.length != 2) {
            System.out.println("Formato inválido! Use: C <codigo_voo>:<num_reserva>");
            return;
        }
        String flightCode = cancelParts[0];
  
        try {
            int cancelReservationId = Integer.parseInt(cancelParts[1]);
            if (!hasFlight(flightCode)) {
                System.out.println("Voo não encontrado.");
                return;
            }
            Flight cancelFlight = flights.get(flightCode);
            boolean cancelled = cancelFlight.cancelReservation(cancelReservationId);                        
            if (cancelled) {
                System.out.println("Reserva cancelada com sucesso.");
            } else {
                System.out.println("Reserva não encontrada.");
            }

            flights.get(flightCode).cancelReservation(cancelReservationId);
        } catch (NumberFormatException e) {
            System.out.println("Número de reserva inválido.");
        }
    }




    public Plane choosePlaneToFlight(int[] execNxM, int[] touristNxM){
        Plane plane;
        if (execNxM == null){
            plane = new Plane(touristNxM[0],touristNxM[1]);
        }
        else{
            plane = new Plane(execNxM[0],execNxM[1],touristNxM[0],touristNxM[1]);
        }
        return plane;
    }



    private static int[] parseNxM(String spec) {
        String[] parts = spec.toLowerCase().split("x");
        if (parts.length != 2) throw new IllegalArgumentException("Formato inválido: " + spec);
        int n = Integer.parseInt(parts[0]); // linhas
        int m = Integer.parseInt(parts[1]); // lugares por linha
        return new int[]{n, m};
    }

    public void searchFlightPlaneMap(String code) {
        if (flights.containsKey(code)){
            flights.get(code).getAssociatedPlane().showPlaneSeats();
        }
        else{
            System.out.printf("Avião de código %s não encontrado!\n",code);
        }
    }

    private  void addNewFlight(String code, Flight newFlight){
        if(!flights.containsKey(code)){
            flights.put(code,newFlight);
            System.out.println(newFlight.toString());    
        }
        else{
            System.out.println("Voo " + code + " já existe!");
        }
    }


    public boolean readFlightFile(String nameFile) {
        File file = new File(nameFile);
        try(Scanner sc = new Scanner(file)){
            String lineFile;
            String currentFlightCode = null;
            while(sc.hasNextLine()){
                lineFile = sc.nextLine().trim();
                if(lineFile.startsWith(">")){
                    // substring para retirar o prefixo ">
                    createFlight(lineFile.substring(1).split(" "));
                    currentFlightCode = lineFile.substring(1).split(" ")[0];
                }else if (!lineFile.isEmpty() && currentFlightCode != null){
                    reserveFlight(currentFlightCode, lineFile.split(" "));
                }
            }
        return true;
        }catch(FileNotFoundException e ){
            System.out.println("File not Found!");
            return false;
        }
    }


    public static String[] removeCommandDigit(String[] parts) {
        return Arrays.copyOfRange(parts, 1, parts.length);
    }

    public void prepareInputToReserve(String[] parts){
        String[] partsWhithoutCommand = removeCommandDigit(parts);
        String flightCode = partsWhithoutCommand[0];
        String[] inputToReserve = Arrays.copyOfRange(partsWhithoutCommand, 1, partsWhithoutCommand.length);
        reserveFlight(flightCode,inputToReserve);
    }

    public Flight getFlight(String code) {
        return flights.get(code);
    }

    public boolean hasFlight(String code) {
        return flights.containsKey(code);
    }

}
