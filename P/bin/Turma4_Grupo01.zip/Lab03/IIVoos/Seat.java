package IIVoos;

public class Seat {
    private final char line;
    private final int lineNumber;
    private int reservationId; //0 é livre 

    Seat(char line, int lineNumber){
        this.line = line;
        this.lineNumber = lineNumber;
        this.reservationId = 0; //começa livre
    }

    public boolean seatIsFree(){
        return reservationId == 0;
    }

    public void reserveSeat(int reservationId){
        this.reservationId = reservationId;
    }

    public void setSeatFree(){
        this.reservationId = 0;
    }

    public char getLine() {
        return line;
    }

    public int getCol() {
        return lineNumber;
    }


    public int getReservationId() {
        return reservationId;
    }

    @Override
    public String toString(){
        return String.format("%3d", this.reservationId);
    }

    
    
}
