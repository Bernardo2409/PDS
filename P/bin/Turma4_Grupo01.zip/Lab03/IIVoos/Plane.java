package IIVoos;

import java.util.HashMap;

public class Plane {
    //Atributos
    private final Character START_LETTER_LINES = 'A';
    private HashMap<Character,Seat[]> planeExecutiveSeats;
    private final HashMap<Character,Seat[]> planeTouristSeats;



    //Construtor
    public Plane(int execSeatsPerLine, int execLines, int touristSeatsPerLine, int touristLines){
        setPlaneSeats(planeExecutiveSeats = new HashMap<>(),execLines, execSeatsPerLine);
        setPlaneSeats(planeTouristSeats = new HashMap<>(),touristLines, touristSeatsPerLine);
    }

    public Plane(int touristSeatsPerLine, int touristLines){
        setPlaneSeats(planeTouristSeats = new HashMap<>(),touristLines, touristSeatsPerLine);
    }


    public void setPlaneSeats(HashMap<Character,Seat[]> planeSeats,int lines, int seatsPerLine) {
        for (int lineIndex = 0; lineIndex < lines; lineIndex++) {
            char rowLetter = (char)(START_LETTER_LINES + lineIndex);
            Seat[] seats = new Seat[seatsPerLine];
            for (int lineNumber = 0; lineNumber < seatsPerLine; lineNumber++) {
                seats[lineNumber] = new Seat(rowLetter, lineNumber);
            }
            planeSeats.put(rowLetter, seats);
        }
    }


    public void showPlaneSeats(){
        showLineNumbers();
        int lines = calculatelines();
        for (int letterIncrement = 0; letterIncrement < lines ;letterIncrement++){
            System.out.print(getLineLetter(letterIncrement));
            if (planeExecutiveSeats != null){
                 showLineSeats(planeExecutiveSeats, getLineLetter(letterIncrement));
            }
            showLineSeats(planeTouristSeats, getLineLetter(letterIncrement));

            System.out.println();
        }
        
    }


    public void showLineNumbers(){
        int columns = planeTouristSeats.get(START_LETTER_LINES).length;
        if (planeExecutiveSeats != null){
            columns += planeExecutiveSeats.get(START_LETTER_LINES).length;
        }
        for(int column = 1; column <= columns; column++){
            System.out.printf("%3d",column);
        }
        System.out.println(); 
    }


    public void showLineSeats(HashMap<Character,Seat[]> seats,char lineLetter){
        if (seats.containsKey(lineLetter)){
            for (Seat seat : seats.get(lineLetter)){
                System.out.print(seat.toString());
            }
        }
        else{
            showEmptySpaces(seats);
        }
    }

    public void showEmptySpaces(HashMap<Character,Seat[]> planeSeats){
        for(int i = 0; i < planeSeats.get(START_LETTER_LINES).length; i++){
                    System.out.printf("%3s"," ");
        }
    }

    public char getLineLetter(int letterIncrement){
        return (char) (this.START_LETTER_LINES + letterIncrement);
    }

    private int calculatelines(){
        if (planeExecutiveSeats == null){
            return planeTouristSeats.size();
        }
        else{
            return Math.max(planeExecutiveSeats.size(), planeTouristSeats.size());
        }
    }



    public boolean haveExecutiveSeats(){
        return (planeExecutiveSeats != null);
    }

    public int getTotalTouristSeats(){
        return planeTouristSeats.size() * planeTouristSeats.get(START_LETTER_LINES).length;
    }

    public int getTotalExecutiveSeats(){
        if (haveExecutiveSeats()){
            return planeExecutiveSeats.size() * planeExecutiveSeats.get(START_LETTER_LINES).length;
        }
        return 0;
    }

    public HashMap<Character,Seat[]> getPlaneTouristSeat(){
        return this.planeTouristSeats;
    }

    public HashMap<Character,Seat[]> getPlaneExecutiveSeat(){
        return this.planeExecutiveSeats;
    }

}
