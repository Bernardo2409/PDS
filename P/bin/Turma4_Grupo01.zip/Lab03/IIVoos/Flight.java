package IIVoos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Flight {
    //ATRIBUTOS
    private String flightCode;
    private Plane associatedPlane;
    private int sequencialReservationNumber = 1;
    private final Map<Integer, List<Seat>> reservations = new HashMap<>();


    public Flight(String code, Plane plane){
        this.flightCode = code;
        this.associatedPlane = plane;
    }

    //GETTERS E SETTERS
    public String getFlightCode() {
        return flightCode;
    }

    public void setFlightCode(String flightCode) {
        this.flightCode = flightCode;
    }

    public Plane getAssociatedPlane(){
        return this.associatedPlane;
    }

    public void sertAssociatedPlane(Plane associatedPlane){
        this.associatedPlane = associatedPlane;
    }


    public boolean cancelReservation(int reservationId) {

        List<Seat> seats = reservations.remove(reservationId);
        if (seats == null) {
            return false; // reserva não existe
        }

        // dar free dos lugares no Plane
        for (Seat seat : seats) {
            seat.setSeatFree();
        }
        return true;
    }

    public int getLastReservationId() {
        return sequencialReservationNumber - 1;
    }  
    
    public Integer getNextReservationId() {
        return sequencialReservationNumber++;
    }

    public static boolean isExecutiveInput(String classType){
        return classType.equals("E");
    }


    public List<Seat> reserveSeats(int quantity, boolean isExecutive){
        HashMap <Character, Seat[]> targetSeats = getTargetSeats(isExecutive);
        if (targetSeats == null){
            return null;
        } 

        List<Character> columns = sortColumns(targetSeats);
        //ver quantas filas existem
        int numRows = targetSeats.get(columns.get(0)).length;
        List<Seat> reserved;

        //tenta numa fila completamente livre
        reserved = reserveFullRow(targetSeats, columns, numRows, quantity);
        if (reserved != null) {
            reservations.put(getNextReservationId(), reserved);
            return reserved;
        }

        // não encontrou fila limpa, tenta sequencialmente
        reserved = reserveSequentially(targetSeats, columns, numRows, quantity);
        if (reserved != null) {
            reservations.put(getNextReservationId(), reserved);
            return reserved;
        }

        return null;
    }
    
    private HashMap <Character, Seat[]> getTargetSeats(boolean isExecutive){
        if(!isExecutive){
            return this.associatedPlane.getPlaneTouristSeat();
        }else if (this.associatedPlane.haveExecutiveSeats()){
            return this.associatedPlane.getPlaneExecutiveSeat();
        }
        else{
            return null;
        }
    }

    private List<Character> sortColumns(HashMap<Character, Seat[]> targetSeats) {
        List<Character> columns = new ArrayList<>(targetSeats.keySet());
        columns.sort(Character::compareTo);
        return columns;
    }

    private List<Seat> reserveFullRow(HashMap<Character, Seat[]> targetSeats, List<Character> columns, int totalRows, int quantity){
        for (int row = 0; row < totalRows; row++) {
            if (isFullRowFree(targetSeats, columns, row, quantity)) {
                return reserveSeatsInRow(targetSeats, columns, row, quantity);
            }
        }
        return null;
    } 
    private boolean isFullRowFree(HashMap<Character, Seat[]> targetSeats, List<Character> columns, int row, int quantity){
        int freeSeats = 0;
        for (Character column: columns){
            Seat seat = targetSeats.get(column)[row];
            if (!seat.seatIsFree()){                    
                return false;
            }
            freeSeats++;
            if (freeSeats == quantity) {
                return true;
            }
        }
        return freeSeats>= quantity;
    }

    private List<Seat> reserveSeatsInRow(HashMap<Character, Seat[]> targetSeats, List<Character> columns, int row, int quantity) {
        List<Seat> reserved = new ArrayList<>();
        for (int i = 0; i < quantity; i++) {
            Seat seat = targetSeats.get(columns.get(i))[row];
            reserved.add(seat);
            for (Seat s : reserved) {
                s.reserveSeat(sequencialReservationNumber);
            }
        }
        return reserved;
    }

    private List<Seat> reserveSequentially(HashMap<Character, Seat[]> targetSeats, List<Character> columns, int totalRows, int quantity) {
        List<Seat> reserved = new ArrayList<>();

        for (int row = 0; row < totalRows; row++) {
            for (Character column : columns) {
                Seat seat = targetSeats.get(column)[row];
                if (seat.seatIsFree()) {
                    reserved.add(seat);
                    if (reserved.size() == quantity) {
                        for(Seat reservedSeat: reserved){
                             reservedSeat.reserveSeat(sequencialReservationNumber);
                        }
                        return reserved;
                    }
                }
            }
        }
        return null;
    }


    @Override
    public String toString() {
        StringBuffer out = new StringBuffer();
        out.append(String.format("Código de voo %s.",this.flightCode));

        if(this.associatedPlane.haveExecutiveSeats()){
            out.append(String.format(" Lugares disponíveis: %d lugares em classe Executiva; %d lugares em classe Turística."
            ,this.associatedPlane.getTotalExecutiveSeats(), this.associatedPlane.getTotalTouristSeats()));
        }
        else{
            out.append(String.format(" Lugares disponíveis: %d lugares em classe Turística.\nClasse executiva não disponível neste voo."
            ,this.associatedPlane.getTotalTouristSeats()));
        }

        return out.toString();
    }



}
